﻿MCDG Multiplayer Test Pack (Server)

Release: 2026-06-02-r2
Generated: 2026-06-02 22:45:57 -04:00
Source instance: D:\ATLauncher\instances\TestInstanceMinecraft1206withFabric

Requirements
- Minecraft 1.20.6 server runtime
- Fabric Loader 0.16.10
- Java 21

Install Steps
1. Stop the server.
2. Back up the current server folder.
3. Copy the folders/files from this pack into the server directory.
4. Confirm required content exists:
   - mods
   - config
   - defaultconfigs
5. Start server and watch startup log for missing mod or mismatch errors.
6. Use USER-GUIDE.txt for command reference and tester instructions.

Multiplayer Rules
- Server and all clients must use the same release ID.
- Do not mix mod files across releases.

Bug Reporting
- Ask testers to submit reports using BUG-REPORT-TEMPLATE.txt.

